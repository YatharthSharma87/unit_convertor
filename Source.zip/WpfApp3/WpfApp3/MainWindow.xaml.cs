﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double i = Convert.ToDouble(meter_input.Text);
            double j = i * 0.000621371;
            mile_output.Text = j.ToString();
        }

        public void Button_Click_1(object sender, RoutedEventArgs e)
        {
            double i = Convert.ToDouble(celsius_input.Text);
            double j = (i * (1.80)) + 32;
            string k = j.ToString();
            if (k.Length == 0)
            {
                celsius_input.Text = "Please enter a value!";
            }
            else
            {
                fahrenheit_output.Text = k;
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            double i = Convert.ToDouble(fahrenheit_input.Text);
            double j = ((i - 32) *5);
            double k = j / 9;
            celsius_output.Text = k.ToString();
        }
    }
}
